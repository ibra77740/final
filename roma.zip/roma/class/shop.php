<?php

class shop{
    public $id_article ;
    public $nb ;
    
    function __construct($id_article,$nb) {
        $this->id=$id ;
        $this->nb=$nb ;

    }
    
    function get_total($id_article){
        return $nb * 
    }
    
}


?>