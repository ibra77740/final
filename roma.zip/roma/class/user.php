<?php

class User {
    
    public $nom ;  
    public $prenom ;
    public $email ;
    public $password ;
    public $panel ; 
    public $adr ;
    public $date ;
    public $historique ; 
    public $fav;

    function __construct($nom,$prenom,$email,$password,$adr,$date,$panel,$historique,$fav){
        $this->nom = $nom ;
        $this->prenom = $prenom ;
        $this->email = $email ;
        $this->password = $password ;
        $this->adr = $adr ;
        $this->date = $date ;
        $this->panel = $panel ; 
        $this->historique  = $historique ;
        $this->fav= $fav;
    }

    function add($id_article ){
        array_push($this->panel,$id_article);
    }

    function delete($id_article){
        if (($key = array_search($id_article,$this->panel)) !== false) {
            unset($this->panel[$key]);
        }
    }
    function empty_hist(){
        $this->historique=[] ;
    }


    function delete_panel(){
        $this->panel=[];
    }

    function add_fav($id_article){
        array_push($this->fav,$id_article);

    }

    function delete_fav($id_article){
        if (($key = array_search($id_article,$this->fav)) !== false) {
            unset($this->fav[$key]);
        }
    }
    

    



}




?>