<?php

class Article {
    
    public $id ;
    public $nom ;
    public $date ;
    public $desc ;
    public $imgArt ;
    public $imgs ;
    public $place ;
    public $prix ;
    public $categories ;

    function __construct($id,$nom,$date,$desc,$imgArt,$imgs,$place,$prix,$categories){
        $this->id=$id ;
        $this->nom=$nom ;
        $this->date=$date;
        $this->desc = $desc ;
        $this->imgArt = $imgArt ;
        $this->imgs = $imgs;
        $this->place = $place ;
        $this->prix =  $prix; 
    }
    










}



?>