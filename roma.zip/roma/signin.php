
<?php


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require "traitement_sign_in.php";

?>

<!DOCTYPE HTML>
<!--
	Solid State by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Solid State by HTML5 UP</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css" integrity="sha512-rRQtF4V2wtAvXsou4iUAs2kXHi3Lj9NE7xJR77DE7GHsxgY9RTWy93dzMXgDIG8ToiRTD45VsDNdTiUagOFeZA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
		<link rel="stylesheet" href="card.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/purecss@3.0.0/build/pure-min.css" integrity="sha384-X38yfunGUhNzHpBaEBsWLO+A0HDYOQi8ufWDkZ0k9e0eXz/tH3II7uKZ9msv++Ls" crossorigin="anonymous">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
		<link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>

		<style>
			#banner {
				padding: 10em 0 4.75em 0 ;
				height: 400px;
				
			}
            form >  .fields {
			display: -moz-flex;
			display: -webkit-flex;
			display: -ms-flex;
			display: flex;
			-moz-flex-wrap: wrap;
			-webkit-flex-wrap: wrap;
			-ms-flex-wrap: wrap;
			flex-wrap: wrap;
			width: calc(100% + 3rem);
			margin: -1.5rem 0 2rem -1.5rem;
		}

			form >  .fields > .field {
				-moz-flex-grow: 0;
				-webkit-flex-grow: 0;
				-ms-flex-grow: 0;
				flex-grow: 0;
				-moz-flex-shrink: 0;
				-webkit-flex-shrink: 0;
				-ms-flex-shrink: 0;
				flex-shrink: 0;
				padding: 1.5rem 0 0 1.5rem;
				width: calc(100% - 1.5rem);
			}

				form > .fields > .field.half {
					width: calc(50% - 0.75rem);
				}

				form > .fields > .field.third {
					width: calc(100%/3 - 0.5rem);
				}

				form > .fields > .field.quarter {
					width: calc(25% - 0.375rem);
				}

		@media screen and (max-width: 480px) {

			form > .fields {
				width: calc(100% + 3rem);
				margin: -1.5rem 0 2rem -1.5rem;
			}

				form > .fields > .field {
					padding: 1.5rem 0 0 1.5rem;
					width: calc(100% - 1.5rem);
				}

					form > .fields > .field.half {
						width: calc(100% - 1.5rem);
					}

					form > .fields > .field.third {
						width: calc(100% - 1.5rem);
					}

					form > .fields > .field.quarter {
						width: calc(100% - 1.5rem);
					}

		}

        .signupform  label {
		color: #ffffff;
		display: block;
		font-size: 0.8rem;
		font-weight: 300;
		letter-spacing: 0.2rem;
		line-height: 1.5;
		margin: 0 0 1rem 0;
		text-transform: uppercase;
	}

	.signupform  input[type="text"],
    .signupfrom  input[type="date"],
	.signupform  input[type="password"],
	.signupform  input[type="email"],
	.signupform input[type="tel"],
	.signupform  select,
	.signupform textarea {
		-moz-appearance: none;
		-webkit-appearance: none;
		-ms-appearance: none;
		appearance: none;
		-moz-transition: border-color 0.2s ease-in-out, box-shadow 0.2s ease-in-out, background-color 0.2s ease-in-out;
		-webkit-transition: border-color 0.2s ease-in-out, box-shadow 0.2s ease-in-out, background-color 0.2s ease-in-out;
		-ms-transition: border-color 0.2s ease-in-out, box-shadow 0.2s ease-in-out, background-color 0.2s ease-in-out;
		transition: border-color 0.2s ease-in-out, box-shadow 0.2s ease-in-out, background-color 0.2s ease-in-out;
		background-color: transparent;
		border-radius: 4px;
		border: solid 1px #ffffff;
		color: inherit;
		display: block;
		outline: 0;
		padding: 0 1rem;
		text-decoration: none;
		width: 100%;
	}

    .signupform input[type="text"]:invalid,
    .signupform input[type="password"]:invalid,
    .signupform input[type="email"]:invalid,
    .signupform input[type="tel"]:invalid,
    .signupform select:invalid,
    .signupform textarea:invalid {
			box-shadow: none;
		}

		.signupform input[type="text"]:focus,
		.signupform input[type="password"]:focus,
		.signupform input[type="email"]:focus,
		.signupform input[type="tel"]:focus,
		.signupform select:focus,
		.signupform textarea:focus {
			background: rgba(255, 255, 255, 0.075);
			border-color: #ffffff;
			box-shadow: 0 0 0 1px #ffffff;
		}

        .signupform select {
		background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='40' height='40' preserveAspectRatio='none' viewBox='0 0 40 40'%3E%3Cpath d='M9.4,12.3l10.4,10.4l10.4-10.4c0.2-0.2,0.5-0.4,0.9-0.4c0.3,0,0.6,0.1,0.9,0.4l3.3,3.3c0.2,0.2,0.4,0.5,0.4,0.9 c0,0.4-0.1,0.6-0.4,0.9L20.7,31.9c-0.2,0.2-0.5,0.4-0.9,0.4c-0.3,0-0.6-0.1-0.9-0.4L4.3,17.3c-0.2-0.2-0.4-0.5-0.4-0.9 c0-0.4,0.1-0.6,0.4-0.9l3.3-3.3c0.2-0.2,0.5-0.4,0.9-0.4S9.1,12.1,9.4,12.3z' fill='%23ffffff' /%3E%3C/svg%3E");
		background-size: 1.25rem;
		background-repeat: no-repeat;
		background-position: calc(100% - 1rem) center;
		height: 2.75rem;
		padding-right: 2.75rem;
		text-overflow: ellipsis;
	}

    .signupform select option {
			color: #ffffff;
			background: #1b1f22;
		}

		.signupform select:focus::-ms-value {
			background-color: transparent;
		}

		.signupform select::-ms-expand {
			display: none;
		}

        .signupform input[type="text"],
        .signupfrom  input[type="date"],
        .signupform input[type="password"],
        .signupform input[type="email"],
        .signupform select {
		height: 2.75rem;
	}

	.signupform textarea {
		padding: 0.75rem 1rem;
	}

	.signupform input[type="checkbox"],
	.signupform input[type="radio"] {
		-moz-appearance: none;
		-webkit-appearance: none;
		-ms-appearance: none;
		appearance: none;
		display: block;
		float: left;
		margin-right: -2rem;
		opacity: 0;
		width: 1rem;
		z-index: -1;
	}

    .signupform input[type="checkbox"] + label,
    .signupform input[type="radio"] + label {
			text-decoration: none;
			-moz-user-select: none;
			-webkit-user-select: none;
			-ms-user-select: none;
			user-select: none;
			color: #ffffff;
			cursor: pointer;
			display: inline-block;
			font-size: 0.8rem;
			font-weight: 300;
			margin: 0 0 0.5rem 0;
			padding-left: 2.65rem;
			padding-right: 0.75rem;
			position: relative;
		}

        .signupform input[type="checkbox"] + label:before,
        .signupform input[type="radio"] + label:before {
				-moz-osx-font-smoothing: grayscale;
				-webkit-font-smoothing: antialiased;
				display: inline-block;
				font-style: normal;
				font-variant: normal;
				text-rendering: auto;
				line-height: 1;
				text-transform: none !important;
				font-family: 'Font Awesome 5 Free';
				font-weight: 900;
			}

			.signupform input[type="checkbox"] + label:before,
			.signupform input[type="radio"] + label:before {
				-moz-transition: border-color 0.2s ease-in-out, box-shadow 0.2s ease-in-out, background-color 0.2s ease-in-out;
				-webkit-transition: border-color 0.2s ease-in-out, box-shadow 0.2s ease-in-out, background-color 0.2s ease-in-out;
				-ms-transition: border-color 0.2s ease-in-out, box-shadow 0.2s ease-in-out, background-color 0.2s ease-in-out;
				transition: border-color 0.2s ease-in-out, box-shadow 0.2s ease-in-out, background-color 0.2s ease-in-out;
				border-radius: 4px;
				border: solid 1px #ffffff;
				content: '';
				display: inline-block;
				height: 1.65rem;
				left: 0;
				line-height: 1.65rem;
				position: absolute;
				text-align: center;
				top: -0.15rem;
				width: 1.65rem;
			}

            .signupform input[type="checkbox"]:checked + label:before,
            .signupform input[type="radio"]:checked + label:before {
			background: #ffffff !important;
			border-color: #ffffff !important;
			color: #1b1f22;
			content: '\f00c';
		}

		.signupform input[type="checkbox"]:focus + label:before,
		.signupform input[type="radio"]:focus + label:before {
			background: rgba(255, 255, 255, 0.075);
			border-color: #ffffff;
			box-shadow: 0 0 0 1px #ffffff;
		}

        .signupform input[type="checkbox"] + label:before {
		border-radius: 4px;
	}

	.signupform input[type="radio"] + label:before {
		border-radius: 100%;
	}

	::-webkit-input-placeholder {
		color: rgba(255, 255, 255, 0.5) !important;
		opacity: 1.0;
	}

	:-moz-placeholder {
		color: rgba(255, 255, 255, 0.5) !important;
		opacity: 1.0;
	}

	::-moz-placeholder {
		color: rgba(255, 255, 255, 0.5) !important;
		opacity: 1.0;
	}

	:-ms-input-placeholder {
		color: rgba(255, 255, 255, 0.5) !important;
		opacity: 1.0;
	}

	.signupform  .formerize-placeholder {
		color: rgba(255, 255, 255, 0.5) !important;
		opacity: 1.0;
	}
    .signup{
        display: flex;
        justify-content: center;
        margin: 100px;
    }
    .signupform{
        border-radius: 4px;
        position: relative;
        width: 50%;
        padding: 40px;
        background-color: black;
    }
    .signupform .birth{
        -moz-appearance: none;
		-webkit-appearance: none;
		-ms-appearance: none;
		appearance: none;
		-moz-transition: border-color 0.2s ease-in-out, box-shadow 0.2s ease-in-out, background-color 0.2s ease-in-out;
		-webkit-transition: border-color 0.2s ease-in-out, box-shadow 0.2s ease-in-out, background-color 0.2s ease-in-out;
		-ms-transition: border-color 0.2s ease-in-out, box-shadow 0.2s ease-in-out, background-color 0.2s ease-in-out;
		transition: border-color 0.2s ease-in-out, box-shadow 0.2s ease-in-out, background-color 0.2s ease-in-out;
		background-color: transparent;
		border-radius: 4px;
        height:45px;
		border: solid 1px #ffffff;
		color: inherit;
		display: block;
		outline: 0;
		padding: 0 1rem;
		text-decoration: none;
		width: 100%;
    }
    .actions {
        margin: 50px;
        margin-bottom: 10px;
        
    }
    .signupbut {

        display: inline-block;
            outline: none;
            cursor: pointer;
            border-radius: 3px;
            
            line-height: 16px;
            padding: 2px 16px;
            height: 38px;
            margin: 3px;
            min-width: 96px;
            min-height: 38px;
            font-size: 20px;
            font-weight: 900;
            border: none;
            color: #fff;
            background-color: rgb(88, 101, 242);
            transition: background-color .17s ease,color .17s ease;
        

        }
        .signinbut:hover {
                background-color: rgb(71, 82, 196);
            }
   
			
			</style>
	</head>
	<body class="is-preload">
		<div class="mynav ">
		<div class="rightnav ">
			<ul>
				<li id="home" class="home" >Acceul</li>
				<li id="products" >Produits</li>
				<li id="surdemande">sur demande</li>
			</ul>
		</div>
		<div class="searchcontainer ">
			<input type="text" class="searchinput" placeholder="search...">
		</div>
		<div class="account pure-g">
			<!-- <i class="fa-solid fa-bag-shopping card selected" ></i>
			<span class="username">sasuke utchiha</span>
			<i class="fa-regular fa-user user"></i> -->
            <button class="signupbut">Sign Up</button>
		</div>
		</div>
		<!-- Page Wrapper -->
			<div id="page-wrapper">

				<!-- Header -->
				
					

				<!-- Menu -->
					<nav id="menu">
						<div class="inner">
							<h2>Menu</h2>
							<ul class="links">
								<li><a href="index.html">Home</a></li>
								<li><a href="generic.html">Generic</a></li>
								<li><a href="elements.html">Elements</a></li>
								<li><a href="#">Log In</a></li>
								<li><a href="#">Sign Up</a></li>
							</ul>
							<a href="#" class="close">Close</a>
						</div>
					</nav>
                    <section class="paneltitles">

                    </section>
                    
                    <section class="signup">
                        <div class="signupform">
                            <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                                <div class="fields">
                                   
                                    <div class="field half">
                                        <label for="name">email</label>
                                        <input type="email" name="email" id="name" />
                                    </div>
                                   
                                    <div class="field half">
                                        <label for="name">password</label>
                                        <input type="password" name="password" id="name" />
                                    </div>
                                <div class="buttonlabel pure-g">
                                    <ul class="actions">
                                        <li><input type="submit" value="sign in" class="primary" /></li>
                                        <li><input type="reset" value="Reset" /></li>
                                    </ul>
                                </div> 
                                
                            </form>
                        </div>
                    </section>

					
			
							<footer>
								<div class="footer">
								<div class="row social">
								<a href="#"><i  class="fa fa-facebook"></i></a>
								<a href="#"><i class="fa fa-instagram"></i></a>
								<a href="#"><i class="fa fa-youtube"></i></a>
								<a href="#"><i class="fa fa-twitter"></i></a>
								</div>
								
								<div class="row links">
								<ul>
								<li><a href="#">Contact us</a></li>
								<li><a href="#">Our Services</a></li>
								<li><a href="#">Privacy Policy</a></li>
								<li><a href="#">Terms & Conditions</a></li>
								<li><a href="#">Career</a></li>
								</ul>
								</div>
								
								<div class="row">
								INFERNO Copyright © 2021 Inferno - All rights reserved || Designed By: Mahesh 
								</div>
								</div>
								</footer>
					

				

							














					
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
			<script>
				const rangeInput = document.querySelectorAll(".range-input input"),
				priceInput = document.querySelectorAll(".price-input input"),
				range = document.querySelector(".slider .progress");
				let priceGap = 1000;
				priceInput.forEach(input =>{
					input.addEventListener("input", e =>{
						let minPrice = parseInt(priceInput[0].value),
						maxPrice = parseInt(priceInput[1].value);
						
						if((maxPrice - minPrice >= priceGap) && maxPrice <= rangeInput[1].max){
							if(e.target.className === "input-min"){
								rangeInput[0].value = minPrice;
								range.style.left = ((minPrice / rangeInput[0].max) * 100) + "%";
							}else{
								rangeInput[1].value = maxPrice;
								range.style.right = 100 - (maxPrice / rangeInput[1].max) * 100 + "%";
							}
						}
					});
				});
				rangeInput.forEach(input =>{
					input.addEventListener("input", e =>{
						let minVal = parseInt(rangeInput[0].value),
						maxVal = parseInt(rangeInput[1].value);
						if((maxVal - minVal) < priceGap){
							if(e.target.className === "range-min"){
								rangeInput[0].value = maxVal - priceGap
							}else{
								rangeInput[1].value = minVal + priceGap;
							}
						}else{
							priceInput[0].value = minVal;
							priceInput[1].value = maxVal;
							range.style.left = ((minVal / rangeInput[0].max) * 100) + "%";
							range.style.right = 100 - (maxVal / rangeInput[1].max) * 100 + "%";
						}
					});
				});
			</script>

	</body>
</html>